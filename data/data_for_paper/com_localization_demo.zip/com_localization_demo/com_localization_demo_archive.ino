#include <Servo.h>

Servo leftServo;
Servo rightServo;
Servo gripperServo;

const int LEFT_SERVO_PIN    = 9;
const int RIGHT_SERVO_PIN   = 10;
const int GRIPPER_SERVO_PIN = 6;

// ---------- Trajectory 1 ----------
const uint16_t motion1[][4] = {
  {180, 0, 20, 249},
  {180, 2, 20, 2858},
  {180, 10, 20, 103},
  {180, 18, 20, 102},
  {180, 26, 20, 103},
  {180, 34, 20, 103},
  {180, 42, 20, 102},
  {180, 50, 20, 103},
  {180, 58, 20, 102},
  {180, 66, 20, 104},
  {172, 66, 20, 510},
  {164, 66, 20, 103},
  {162, 66, 20, 102},
  {162, 70, 20, 205},
  {162, 78, 20, 103},
  {162, 86, 20, 102},
  {162, 94, 20, 102},
  {162, 100, 20, 104},
  {160, 100, 20, 102},
  {152, 100, 20, 103},
  {144, 100, 20, 102},
  {140, 100, 20, 103},
  {140, 106, 20, 205},
  {140, 114, 20, 103},
  {140, 122, 20, 102},
  {136, 126, 20, 102},
  {128, 126, 20, 104},
  {124, 126, 20, 102},
  {124, 130, 20, 205},
  {124, 138, 20, 103},
  {124, 146, 20, 102},
  {118, 152, 20, 103},
  {110, 152, 20, 103},
  {102, 152, 20, 102},
  {94, 152, 20, 104},
  {86, 152, 20, 102},
  {84, 152, 20, 102},
  {84, 154, 20, 409},
  {84, 162, 20, 102},
  {84, 170, 20, 104},
  {76, 170, 20, 306},
  {68, 170, 20, 102},
  {62, 170, 20, 104},
  {62, 176, 20, 510},
  {62, 180, 20, 103},
};

const int NUM_STEPS_1 = sizeof(motion1) / sizeof(motion1[0]);

// ---------- Trajectory 2 ----------
const uint16_t motion2[][4] = {
  {180, 0, 20, 249},
  {178, 0, 20, 3165},
  {170, 0, 20, 102},
  {162, 0, 20, 102},
  {154, 0, 20, 103},
  {146, 0, 20, 102},
  {138, 0, 20, 104},
  {130, 0, 20, 102},
  {122, 0, 20, 102},
  {118, 0, 20, 103},
  {118, 8, 20, 511},
  {118, 16, 20, 102},
  {118, 18, 20, 103},
  {116, 18, 20, 204},
  {108, 18, 20, 103},
  {102, 18, 20, 102},
  {102, 20, 20, 205},
  {102, 28, 20, 103},
  {102, 34, 20, 103},
  {98, 34, 20, 102},
  {90, 34, 20, 103},
  {84, 34, 20, 102},
  {84, 42, 20, 307},
  {84, 50, 20, 103},
  {78, 50, 20, 408},
  {74, 50, 20, 103},
  {74, 52, 20, 204},
  {74, 60, 20, 103},
  {74, 68, 20, 103},
  {74, 72, 20, 103},
  {72, 72, 20, 204},
  {64, 72, 20, 103},
  {60, 72, 20, 102},
  {60, 76, 20, 306},
  {60, 84, 20, 104},
  {60, 88, 20, 102},
  {54, 88, 20, 103},
  {46, 88, 20, 102},
  {38, 88, 20, 102},
  {36, 88, 20, 103},
  {36, 94, 20, 1021},
  {36, 100, 20, 103},
  {32, 100, 20, 816},
  {24, 100, 20, 104},
};

const int NUM_STEPS_2 = sizeof(motion2) / sizeof(motion2[0]);

const int SERVO_MIN = 0;
const int SERVO_MAX = 180;
const int GRIPPER_MIN = 0;
const int GRIPPER_MAX = 180;

const int GRIPPER_CLOSED_ANGLE = 180;
const int GRIPPER_OPEN_ANGLE   = 0;

const unsigned long WAIT_BEFORE_GRIP_MS = 5000;
const int GRIPPER_STEP_DELAY_MS = 40;

const int LIFT_DELTA_SIGN = -1;
const int LIFT_TOTAL_STEPS = 70;
const int LIFT_STEP_DELAY_MS = 100;

bool hasRun = false;

void setup() {
  Serial.begin(9600);

  leftServo.attach(LEFT_SERVO_PIN);
  rightServo.attach(RIGHT_SERVO_PIN);
  gripperServo.attach(GRIPPER_SERVO_PIN);

  leftServo.write(motion1[0][0]);
  rightServo.write(motion1[0][1]);
  gripperServo.write(motion1[0][2]);

  delay(1000);
  Serial.println("ARDUINO1_READY");
}

void loop() {
  if (hasRun) return;

  if (Serial.available() > 0) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();

    if (cmd == "START") {
      bool pass1 = runRoutineWithMatlabCheck(motion1, NUM_STEPS_1);

      if (!pass1) {
        bool pass2 = runRoutineWithMatlabCheck(motion2, NUM_STEPS_2);
      }

      Serial.println("DONE");
      hasRun = true;
    }
  }
}

bool runRoutineWithMatlabCheck(const uint16_t motion[][4], int numSteps) {

  for (int i = 0; i < numSteps; i++) {
    leftServo.write(motion[i][0]);
    rightServo.write(motion[i][1]);
    gripperServo.write(motion[i][2]);
    delay(motion[i][3]);
  }

  int leftTarget = motion[numSteps - 1][0];
  int rightTarget = motion[numSteps - 1][1];
  int gripperTarget = motion[numSteps - 1][2];

  delay(WAIT_BEFORE_GRIP_MS);

  moveGripperSlow(gripperTarget, GRIPPER_CLOSED_ANGLE);

  int leftLifted = leftTarget;
  int rightLifted = rightTarget;

  for (int k = 0; k < LIFT_TOTAL_STEPS; k++) {
    leftLifted  = constrain(leftLifted  - LIFT_DELTA_SIGN, SERVO_MIN, SERVO_MAX);
    rightLifted = constrain(rightLifted + LIFT_DELTA_SIGN, SERVO_MIN, SERVO_MAX);

    leftServo.write(leftLifted);
    rightServo.write(rightLifted);
    delay(LIFT_STEP_DELAY_MS);
  }

  delay(500);

  Serial.println("READY");

  while (true) {
    if (Serial.available() > 0) {
      String result = Serial.readStringUntil('\n');
      result.trim();

      if (result == "PASS") {
        return true;
      }

      if (result == "FAIL") {
        break;
      }
    }
  }

  for (int k = 0; k < LIFT_TOTAL_STEPS; k++) {
    leftLifted  = constrain(leftLifted  + LIFT_DELTA_SIGN, SERVO_MIN, SERVO_MAX);
    rightLifted = constrain(rightLifted - LIFT_DELTA_SIGN, SERVO_MIN, SERVO_MAX);

    leftServo.write(leftLifted);
    rightServo.write(rightLifted);
    delay(LIFT_STEP_DELAY_MS);
  }

  delay(500);

  moveGripperSlow(GRIPPER_CLOSED_ANGLE, GRIPPER_OPEN_ANGLE);

  delay(500);

  for (int i = numSteps - 1; i >= 0; i--) {
    leftServo.write(motion[i][0]);
    rightServo.write(motion[i][1]);
    gripperServo.write(GRIPPER_OPEN_ANGLE);
    delay(motion[i][3]);
  }

  delay(1000);

  return false;
}

void moveGripperSlow(int startAngle, int endAngle) {
  startAngle = constrain(startAngle, GRIPPER_MIN, GRIPPER_MAX);
  endAngle   = constrain(endAngle,   GRIPPER_MIN, GRIPPER_MAX);

  if (startAngle < endAngle) {
    for (int a = startAngle; a <= endAngle; a++) {
      gripperServo.write(a);
      delay(GRIPPER_STEP_DELAY_MS);
    }
  } else {
    for (int a = startAngle; a >= endAngle; a--) {
      gripperServo.write(a);
      delay(GRIPPER_STEP_DELAY_MS);
    }
  }
}