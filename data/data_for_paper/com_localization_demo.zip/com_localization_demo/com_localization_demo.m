%% MATLAB + Arduino 1 + DAQ COM prediction pipeline
clear; clc;

%% User settings
record_seconds = 3.0;
weights_file = "dynamic_summary_ridge_weights.mat";
target_offset = 0;   % choose only: -3, -2, +2, +3

%% Arduino 1 port
arduino1_port = "COM4";
baud_rate = 9600;

%% NI-DAQ settings
device_id = "cDAQ1Mod4";
channels = "ai" + string(0:11);

save_csv = true;

%% Timing settings
% Attempt 1:
% forward + wait + close + reverse + release ~= 34 s.
% Use 42 s for margin.
attempt1_wait_sec = 42;

% If attempt 1 fails, Arduino automatically completes:
% re-engage -> trajectory 1 place-back -> open -> reverse -> trajectory 2 -> release.
% MATLAB does NOT run second DAQ.
fallback_physical_wait_sec = 90;

%% Load trained weights
S = load(weights_file);

coef = S.coef;
intercept = S.intercept(:)';
mu = S.mu;
stdv = S.std;

all_offsets = S.valid_offsets(:);
all_targets = S.offset_targets_values;

valid_target_offsets = [-4; -3; -2; 2; 3; 4];
keep = ismember(all_offsets, valid_target_offsets);

valid_offsets = all_offsets(keep);
target_values = all_targets(keep, :);

% if ~ismember(target_offset, valid_offsets)
%     error("target_offset must be one of: %s", mat2str(valid_offsets.'));
% end

%% Open Arduino serial port
robot = serialport(arduino1_port, baud_rate);
configureTerminator(robot, "LF");

robot.Timeout = 1;

fprintf("Opened Arduino port %s at %d baud.\n", arduino1_port, baud_rate);

pause(2);
flush(robot);

%% DAQ setup
d = daq("ni");
for i = 1:numel(channels)
    addinput(d, device_id, channels(i), "Voltage");
end

%% Start Arduino with robust startup handshake
waitForStartAck(robot);

%% ---------------- Attempt 1 only ----------------
fprintf("\nAttempt 1: waiting %.1f seconds for motion + grip + reverse + release...\n", attempt1_wait_sec);
pause(attempt1_wait_sec);

fprintf("Attempt 1: starting DAQ recording for %.2f seconds...\n", record_seconds);
data_tt = read(d, seconds(record_seconds));

[pred_offset, pred_xy] = predictOffset(data_tt, coef, intercept, mu, stdv, valid_offsets, target_values);

saveAttemptCsv(data_tt, 1, save_csv);

passed1 = pred_offset == target_offset;

fprintf("\nAttempt 1\n");
fprintf("Target COM offset: %+d\n", target_offset);
fprintf("Predicted readout: x = %.4f, y = %.4f\n", pred_xy(1), pred_xy(2));
fprintf("Predicted COM offset class: %+d\n", pred_offset);

if passed1
    fprintf("Result: PASS\n");
    sendDecisionChar(robot, 'P');

    fprintf("\nPipeline finished after attempt 1 PASS.\n");

    clear robot
    clear d
    return;
else
    fprintf("Result: FAIL\n");
    sendDecisionChar(robot, 'F');

    fprintf("\nAttempt 1 failed. Arduino will now automatically complete fallback trajectory 2.\n");
    fprintf("No second DAQ will be recorded.\n");
    fprintf("Waiting %.1f seconds for physical pipeline completion...\n", fallback_physical_wait_sec);

    pause(fallback_physical_wait_sec);

    fprintf("\nPipeline finished after automatic trajectory 2 fallback.\n");

    clear robot
    clear d
    return;
end

%% ------------------------------------------------------------------------
function waitForStartAck(robot)

    fprintf("Sending START command until Arduino confirms with A...\n");

    max_wait_sec = 20;
    send_interval_sec = 0.5;

    t0 = tic;
    last_send_time = -inf;

    while toc(t0) < max_wait_sec

        if toc(t0) - last_send_time >= send_interval_sec
            writeline(robot, "S");
            fprintf("MATLAB -> Arduino: S\n");
            last_send_time = toc(t0);
        end

        msg = readAvailableLine(robot);

        if msg == ""
            continue;
        end

        fprintf("Arduino -> MATLAB: %s\n", msg);

        if msg == "A"
            fprintf("Arduino confirmed start.\n");
            return;
        end
    end

    error("Arduino did not confirm START with A within %.1f seconds.", max_wait_sec);
end

function sendDecisionChar(robot, decisionChar)

    fprintf("Sending decision %c once as raw byte...\n", decisionChar);

    try
        write(robot, uint8(decisionChar), "uint8");
        fprintf("MATLAB -> Arduino: %c\n", decisionChar);
    catch ME
        error("Failed to send decision %c to Arduino. Serial device is unhealthy: %s", ...
            decisionChar, ME.message);
    end

    pause(0.2);
end

function [pred_offset, pred_xy] = predictOffset(data_tt, coef, intercept, mu, stdv, valid_offsets, target_values)

    X_raw = data_tt.Variables;

    baseline = X_raw(1, :);
    X_disp = X_raw - baseline;

    feat = build_dynamic_summary_feature(X_disp);

    if size(feat, 2) ~= size(mu, 2)
        error("Feature mismatch. MATLAB dim = %d, trained dim = %d.", ...
            size(feat, 2), size(mu, 2));
    end

    xn = (feat - mu) ./ stdv;

    pred_xy = xn * coef.' + intercept;

    dist = vecnorm(target_values - pred_xy, 2, 2);
    [~, idx] = min(dist);
    pred_offset = valid_offsets(idx);
end

function saveAttemptCsv(data_tt, attempt, save_csv)

    if ~save_csv
        return;
    end

    csv_file = sprintf("attempt_%d_sensor_data.csv", attempt);
    T_table = timetable2table(data_tt);
    T_table.Time = seconds(T_table.Time);
    writetable(T_table, csv_file);

    fprintf("Saved sensor data to %s\n", csv_file);
end

function msg = readAvailableLine(robot)

    msg = "";

    if robot.NumBytesAvailable <= 0
        pause(0.02);
        return;
    end

    try
        raw = readline(robot);
    catch
        return;
    end

    if isempty(raw)
        return;
    end

    if isstring(raw) || ischar(raw)
        msg = string(strtrim(raw));
    else
        return;
    end

    if strlength(msg) == 0
        msg = "";
    end
end

function feat = build_dynamic_summary_feature(X)

    early_frac = 0.35;
    late_frac = 0.35;

    T = size(X, 1);

    n_early = max(1, floor(early_frac * T));
    n_late = max(1, floor(late_frac * T));

    X_early = X(1:n_early, :);
    X_late = X(end-n_late+1:end, :);

    full_mean = mean(X, 1);
    full_std = std(X, 0, 1);

    early_mean = mean(X_early, 1);
    late_mean = mean(X_late, 1);

    early_std = std(X_early, 0, 1);
    late_std = std(X_late, 0, 1);

    delta_mean = late_mean - early_mean;
    rms_val = sqrt(mean(X.^2, 1));

    feat = [ ...
        full_mean, ...
        full_std, ...
        early_mean, ...
        late_mean, ...
        early_std, ...
        late_std, ...
        delta_mean, ...
        rms_val ...
    ];
end