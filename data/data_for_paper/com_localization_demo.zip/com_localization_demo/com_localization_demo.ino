#include <Servo.h>
#include <string.h>

Servo leftServo;
Servo rightServo;
Servo gripperServo;

const int LEFT_SERVO_PIN    = 9;
const int RIGHT_SERVO_PIN   = 10;
const int GRIPPER_SERVO_PIN = 6;

// ---------- Trajectory 1 ----------
const uint16_t motion1[][4] = {
  {180, 0, 20, 249},
  {180, 2, 20, 2858},
  {180, 10, 20, 103},
  {180, 18, 20, 102},
  {180, 26, 20, 103},
  {180, 34, 20, 103},
  {180, 42, 20, 102},
  {180, 50, 20, 103},
  {180, 58, 20, 102},
  {180, 66, 20, 104},
  {172, 66, 20, 510},
  {164, 66, 20, 103},
  {162, 66, 20, 102},
  {162, 70, 20, 205},
  {162, 78, 20, 103},
  {162, 86, 20, 102},
  {162, 94, 20, 102},
  {162, 100, 20, 104},
  {160, 100, 20, 102},
  {152, 100, 20, 103},
  {144, 100, 20, 102},
  {140, 100, 20, 103},
  {140, 106, 20, 205},
  {140, 114, 20, 103},
  {140, 122, 20, 102},
  {136, 126, 20, 102},
  {128, 126, 20, 104},
  {124, 126, 20, 102},
  {124, 130, 20, 205},
  {124, 138, 20, 103},
  {124, 146, 20, 102},
  {118, 152, 20, 103},
  {110, 152, 20, 103},
  {102, 152, 20, 102},
  {94, 152, 20, 104},
  {86, 152, 20, 102},
  {84, 152, 20, 102},
  {84, 154, 20, 409},
  {84, 162, 20, 102},
  {84, 170, 20, 104},
  {76, 170, 20, 306},
  {68, 170, 20, 102},
  {62, 170, 20, 104},
  {62, 176, 20, 510},
  {62, 180, 20, 103},
};
const int NUM_STEPS_1 = sizeof(motion1) / sizeof(motion1[0]);

// ---------- Trajectory 2 ----------
const uint16_t motion2[][4] = {
  {180, 0, 20, 249},
  {178, 0, 20, 3165},
  {170, 0, 20, 102},
  {162, 0, 20, 102},
  {154, 0, 20, 103},
  {146, 0, 20, 102},
  {138, 0, 20, 104},
  {130, 0, 20, 102},
  {122, 0, 20, 102},
  {118, 0, 20, 103},
  {118, 8, 20, 511},
  {118, 16, 20, 102},
  {118, 18, 20, 103},
  {116, 18, 20, 204},
  {108, 18, 20, 103},
  {102, 18, 20, 102},
  {102, 20, 20, 205},
  {102, 28, 20, 103},
  {102, 34, 20, 103},
  {98, 34, 20, 102},
  {90, 34, 20, 103},
  {84, 34, 20, 102},
  {84, 42, 20, 307},
  {84, 50, 20, 103},
  {78, 50, 20, 408},
  {74, 50, 20, 103},
  {74, 52, 20, 204},
  {74, 60, 20, 103},
  {74, 68, 20, 103},
  {74, 72, 20, 103},
  {72, 72, 20, 204},
  {64, 72, 20, 103},
  {60, 72, 20, 102},
  {60, 76, 20, 306},
  {60, 84, 20, 104},
  {60, 88, 20, 102},
  {54, 88, 20, 103},
  {46, 88, 20, 102},
  {38, 88, 20, 102},
  {36, 88, 20, 103},
  {36, 94, 20, 1021},
  {36, 100, 20, 103},
  {32, 100, 20, 816},
  {24, 100, 20, 104},
};
const int NUM_STEPS_2 = sizeof(motion2) / sizeof(motion2[0]);

const int GRIPPER_MIN          = 0;
const int GRIPPER_MAX          = 180;
const int GRIPPER_CLOSED_ANGLE = 180;
const int GRIPPER_OPEN_ANGLE   = 0;

const unsigned long WAIT_BEFORE_GRIP_MS = 5000;
const int GRIPPER_STEP_DELAY_MS = 40;

// Release/no-load pose
const int RELEASE_LEFT_ANGLE  = 0;
const int RELEASE_RIGHT_ANGLE = 180;

// Arm slow re-engage/release settings
const int ARM_STEP_DEG = 2;
const int ARM_STEP_DELAY_MS = 25;

// Smooth same-timing place-back setting
const int SMOOTH_STEP_DEG = 2;
const unsigned long MIN_SMOOTH_SUBDELAY_MS = 10;

const unsigned long RELEASE_HOLD_MS = 1000;
const unsigned long SETTLE_AFTER_REENGAGE_MS = 1500;
const unsigned long SETTLE_AT_PLACEBACK_MS = 500;
const unsigned long SETTLE_AFTER_OPEN_MS = 500;

const int CMD_BUF_SIZE = 12;

bool running = false;
unsigned long lastBootPrint = 0;

void setup() {
  Serial.begin(9600);

  pinMode(LED_BUILTIN, OUTPUT);

  leftServo.attach(LEFT_SERVO_PIN);
  rightServo.attach(RIGHT_SERVO_PIN);
  gripperServo.attach(GRIPPER_SERVO_PIN);

  leftServo.write(motion1[0][0]);
  rightServo.write(motion1[0][1]);
  gripperServo.write(motion1[0][2]);

  delay(1000);

  Serial.println("B");
  lastBootPrint = millis();
}

void loop() {
  if (!running && millis() - lastBootPrint >= 1000) {
    Serial.println("B");
    lastBootPrint = millis();
  }

  char cmd[CMD_BUF_SIZE];

  if (readCommand(cmd, sizeof(cmd))) {
    if (!running && strcmp(cmd, "S") == 0) {
      running = true;

      Serial.println("A");

      bool pass1 = runAttempt1AndWaitDecision();

      if (!pass1) {
        runAttempt2NoDecision();
      }

      Serial.println("D");
      running = false;
    }
  }
}

bool runAttempt1AndWaitDecision() {

  // 1. Attempt 1 forward trajectory to object
  playForwardWithGripper(motion1, NUM_STEPS_1);

  int gripperTarget = motion1[NUM_STEPS_1 - 1][2];

  // 2. Wait before gripping
  delay(WAIT_BEFORE_GRIP_MS);

  // 3. Close gripper
  moveGripperSlow(gripperTarget, GRIPPER_CLOSED_ANGLE);

  delay(500);

  // 4. Reverse back to initial lifting pose while holding object
  playReverseArmOnly(motion1, NUM_STEPS_1);

  delay(500);

  // 5. Release arm servos to no-load pose before MATLAB DAQ
  moveArmSlow(
    motion1[0][0],
    motion1[0][1],
    RELEASE_LEFT_ANGLE,
    RELEASE_RIGHT_ANGLE,
    ARM_STEP_DEG,
    ARM_STEP_DELAY_MS
  );

  delay(RELEASE_HOLD_MS);

  // 6. MATLAB records DAQ, then sends one raw byte:
  //    'P' = pass, 'F' = fail
  bool passed = waitForDecisionChar();

  if (passed) {
    return true;
  }

  // 7. FAIL: return from release pose to initial lifting pose while holding object
  moveArmSlow(
    RELEASE_LEFT_ANGLE,
    RELEASE_RIGHT_ANGLE,
    motion1[0][0],
    motion1[0][1],
    ARM_STEP_DEG,
    ARM_STEP_DELAY_MS
  );

  delay(SETTLE_AFTER_REENGAGE_MS);

  // 8. Follow trajectory 1 forward again to put object back.
  // Same approximate total timing, but smoother servo updates.
  playForwardArmOnlySmoothSameTiming(motion1, NUM_STEPS_1);

  delay(SETTLE_AT_PLACEBACK_MS);

  // 9. Open gripper at placement pose
  moveGripperSlow(GRIPPER_CLOSED_ANGLE, GRIPPER_OPEN_ANGLE);

  delay(SETTLE_AFTER_OPEN_MS);

  // 10. Reverse back to initial with gripper open
  playReverseArmOnlyWithOpenGripper(motion1, NUM_STEPS_1);

  delay(1000);

  return false;
}

void runAttempt2NoDecision() {

  // 1. Attempt 2 forward trajectory
  playForwardWithGripper(motion2, NUM_STEPS_2);

  int gripperTarget = motion2[NUM_STEPS_2 - 1][2];

  // 2. Wait before gripping
  delay(WAIT_BEFORE_GRIP_MS);

  // 3. Close gripper
  moveGripperSlow(gripperTarget, GRIPPER_CLOSED_ANGLE);

  delay(500);

  // 4. Reverse back to initial lifting pose while holding object
  playReverseArmOnly(motion2, NUM_STEPS_2);

  delay(500);

  // 5. Release arm servos to no-load pose
  moveArmSlow(
    motion2[0][0],
    motion2[0][1],
    RELEASE_LEFT_ANGLE,
    RELEASE_RIGHT_ANGLE,
    ARM_STEP_DEG,
    ARM_STEP_DELAY_MS
  );

  delay(RELEASE_HOLD_MS);

  // No DAQ, no second prediction, no second decision.
}

bool waitForDecisionChar() {
  while (true) {
    if (Serial.available() > 0) {
      char c = (char)Serial.read();

      if (c == 'P' || c == 'p') {
        return true;
      }

      if (c == 'F' || c == 'f') {
        return false;
      }
    }
  }
}

void playForwardWithGripper(const uint16_t motion[][4], int numSteps) {
  for (int i = 0; i < numSteps; i++) {
    leftServo.write(motion[i][0]);
    rightServo.write(motion[i][1]);
    gripperServo.write(motion[i][2]);
    delay(motion[i][3]);
  }
}

void playForwardArmOnly(const uint16_t motion[][4], int numSteps) {
  for (int i = 0; i < numSteps; i++) {
    leftServo.write(motion[i][0]);
    rightServo.write(motion[i][1]);
    delay(motion[i][3]);
  }
}

void playForwardArmOnlySmoothSameTiming(const uint16_t motion[][4], int numSteps) {
  int currentLeft = motion[0][0];
  int currentRight = motion[0][1];

  for (int i = 0; i < numSteps; i++) {
    int targetLeft = motion[i][0];
    int targetRight = motion[i][1];
    unsigned long segmentTime = motion[i][3];

    int dLeft = targetLeft - currentLeft;
    int dRight = targetRight - currentRight;

    int maxDelta = max(abs(dLeft), abs(dRight));
    int nSubSteps = max(1, (maxDelta + SMOOTH_STEP_DEG - 1) / SMOOTH_STEP_DEG);

    unsigned long subDelay = segmentTime / nSubSteps;
    if (subDelay < MIN_SMOOTH_SUBDELAY_MS) {
      subDelay = MIN_SMOOTH_SUBDELAY_MS;
    }

    for (int s = 1; s <= nSubSteps; s++) {
      int leftAngle  = currentLeft  + (long)dLeft  * s / nSubSteps;
      int rightAngle = currentRight + (long)dRight * s / nSubSteps;

      leftServo.write(leftAngle);
      rightServo.write(rightAngle);

      delay(subDelay);
    }

    currentLeft = targetLeft;
    currentRight = targetRight;
  }
}

void playReverseArmOnly(const uint16_t motion[][4], int numSteps) {
  for (int i = numSteps - 1; i >= 0; i--) {
    leftServo.write(motion[i][0]);
    rightServo.write(motion[i][1]);
    delay(motion[i][3]);
  }
}

void playReverseArmOnlyWithOpenGripper(const uint16_t motion[][4], int numSteps) {
  for (int i = numSteps - 1; i >= 0; i--) {
    leftServo.write(motion[i][0]);
    rightServo.write(motion[i][1]);
    gripperServo.write(GRIPPER_OPEN_ANGLE);
    delay(motion[i][3]);
  }
}

void moveGripperSlow(int startAngle, int endAngle) {
  startAngle = constrain(startAngle, GRIPPER_MIN, GRIPPER_MAX);
  endAngle   = constrain(endAngle, GRIPPER_MIN, GRIPPER_MAX);

  if (startAngle < endAngle) {
    for (int a = startAngle; a <= endAngle; a++) {
      gripperServo.write(a);
      delay(GRIPPER_STEP_DELAY_MS);
    }
  } else {
    for (int a = startAngle; a >= endAngle; a--) {
      gripperServo.write(a);
      delay(GRIPPER_STEP_DELAY_MS);
    }
  }
}

void moveArmSlow(int startLeft, int startRight,
                 int endLeft, int endRight,
                 int stepDeg, int stepDelayMs) {

  startLeft  = constrain(startLeft, 0, 180);
  startRight = constrain(startRight, 0, 180);
  endLeft    = constrain(endLeft, 0, 180);
  endRight   = constrain(endRight, 0, 180);

  int dLeft  = endLeft  - startLeft;
  int dRight = endRight - startRight;

  int maxDelta = max(abs(dLeft), abs(dRight));
  int nSteps = max(1, (maxDelta + stepDeg - 1) / stepDeg);

  for (int s = 1; s <= nSteps; s++) {
    int leftAngle  = startLeft  + (long)dLeft  * s / nSteps;
    int rightAngle = startRight + (long)dRight * s / nSteps;

    leftServo.write(leftAngle);
    rightServo.write(rightAngle);

    delay(stepDelayMs);
  }
}

bool readCommand(char *out, size_t outSize) {
  static char buffer[CMD_BUF_SIZE];
  static size_t pos = 0;

  while (Serial.available() > 0) {
    char c = (char)Serial.read();

    if (c == '\r') {
      continue;
    }

    if (c == '\n') {
      buffer[pos] = '\0';

      if (pos == 0) {
        return false;
      }

      strncpy(out, buffer, outSize);
      out[outSize - 1] = '\0';

      pos = 0;
      return true;
    }

    if (pos < CMD_BUF_SIZE - 1) {
      buffer[pos++] = c;
    } else {
      pos = 0;
    }
  }

  return false;
}